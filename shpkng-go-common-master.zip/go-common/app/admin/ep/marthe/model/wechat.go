package model

// WechatContact Wechat Contact
type WechatContact struct {
	EnglishName string `json:"english_name"`
	UserID      string `json:"userid"`
	Name        string `json:"name"`
}
